package com.cg.dao;


import java.util.List;

import com.cg.dto.Customer;

public interface IEWalletDao {

	public Customer addCustomer(Customer customer);
	public Customer showBalance (String mobileNo);
	public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, double amount);
	public Customer depositAmount (String mobileNo,double amount );
	public Customer withdrawAmount(String mobileNo, double amount);
	public List<String> showTransaction(String mobileNo);
	public List<String> displayTransactions();
}
