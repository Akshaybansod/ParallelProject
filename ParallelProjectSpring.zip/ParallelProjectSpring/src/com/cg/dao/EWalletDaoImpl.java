package com.cg.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dto.Customer;
import com.cg.dto.Transaction;
import com.cg.dto.Wallet;
@Repository("dao")

	

public class EWalletDaoImpl implements IEWalletDao {
	
	@PersistenceContext
	EntityManager manager;
	
	private Customer customer;
	private Wallet wallet;
	
	public EWalletDaoImpl() {
		super();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		manager = emf.createEntityManager();
	}
	
	
	@Override
	@Transactional
	public Customer addCustomer(Customer customer) {
		manager.getTransaction().begin();
		wallet = new Wallet(amount);
		customer = new Customer(name, mobileNo, wallet);
		System.out.println(customer);
		manager.persist(customer);
		manager.getTransaction().commit();
		return customer;
		
	}

	
	/*@Override
	public Customer createAccount(String name, String mobileNo, double amount) {
		
		manager.getTransaction().begin();
		wallet = new Wallet(amount);
		customer = new Customer(name, mobileNo, wallet);
		System.out.println(customer);
		manager.persist(customer);
		manager.getTransaction().commit();
		return customer;
		
	}*/
	@Override
	public Customer showBalance(String mobileNo) {
		manager.getTransaction().begin();
		Customer customer = manager.find(Customer.class, mobileNo);
		manager.getTransaction().commit();
		return customer;
		
	}
	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, double amount) {
		/*Customer customer1 = Repository.findOne(sourceMobileNo);
		Customer customer2 = Repository.findOne(targetMobileNo);*/
		manager.getTransaction().begin();
		Customer customer1 = manager.find(Customer.class, sourceMobileNo);
		Customer customer2 = manager.find(Customer.class, targetMobileNo);
		if(customer1!=null)
		{
			double newAmount = customer1.getWallet().getBalance();
			newAmount = newAmount-amount;
			Wallet wallet = new Wallet(newAmount);
			customer1.setWallet(wallet);
			
			/*customer1.getTransaction().getTransaction().add(amount +" transfered to" + customer2.getName());*/
		}
		manager.getTransaction().commit();
		setTrasactions(sourceMobileNo,amount+" transferred to " + targetMobileNo );
		manager.getTransaction().begin();
		if(customer2!=null)
		{
			double newAmount = customer2.getWallet().getBalance();
			newAmount = newAmount+amount;
			Wallet wallet = new Wallet(newAmount);
			customer2.setWallet(wallet);
			
			/*customer2.getTransaction().getTransaction().add(amount +" received from " + customer1.getName());*/
		}
		manager.getTransaction().commit();
		setTrasactions(targetMobileNo, amount+" received from "+ sourceMobileNo);
		return null;
	}
	@Override
	public Customer depositAmount(String mobileNo, double amount) {
		manager.getTransaction().begin();
		Customer customer = manager.find(Customer.class, mobileNo);
		if(customer!=null)
		{
			double newAmount = customer.getWallet().getBalance();
			newAmount = newAmount+amount;
			Wallet wallet = new Wallet(newAmount);
			customer.setWallet(wallet);
			/*customer.getTransaction().getTransaction().add(amount +"deposited");*/
			return customer;
		}
		manager.getTransaction().commit();
		setTrasactions(mobileNo, amount+" deposited");
		return null;
	}
	@Override
	public Customer withdrawAmount(String mobileNo, double amount) {
		manager.getTransaction().begin();
		Customer customer = manager.find(Customer.class, mobileNo);
		if(customer!=null)
		{
			double newAmount = customer.getWallet().getBalance();
			newAmount = newAmount-amount;
			Wallet wallet = new Wallet(newAmount);
			customer.setWallet(wallet);
			/*customer.getTransaction().getTransaction().add(amount +"withdrawn");*/
			
			return customer;
		}
		manager.getTransaction().commit();
		setTrasactions(mobileNo, amount+" Withdrawn");
		return null;
	}
	@Override
	public List<String> showTransaction(String mobileNo) {
		manager.getTransaction().begin();
		String str = "SELECT transaction FROM Transaction transaction ";
		TypedQuery <Transaction> tran = manager.createQuery(str, Transaction.class);
		List<Transaction> list = tran.getResultList();
		for(Transaction t : list){
			System.out.println(t);
		}
		/*Customer customer = manager.find(Customer.class, mobileNo);*/
		/*System.out.println(customer.getTransaction().getTransaction());*/
		
		manager.getTransaction().commit();
		return null;
	}
	 public void setTrasactions (String mobNo, String details){
		 Transaction transaction = new Transaction(mobNo,details);
		 manager.getTransaction().begin();
		 manager.persist(transaction);
		 manager.getTransaction().commit();
	 }


	@Override
	public List<String> displayTransactions() {
		// TODO Auto-generated method stub
		Query query = manager.createQuery("Select t from Transaction t");
		@SuppressWarnings("unchecked")
		List<Transaction> list = query.getResultList();
		return list;
	
	}
	
	 
}
